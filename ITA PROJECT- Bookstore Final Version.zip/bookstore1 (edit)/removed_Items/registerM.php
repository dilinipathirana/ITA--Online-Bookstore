<?php

	$con_str = mysql_connect("localhost", "root", "") or die("Can't Connect...");

	mysql_select_db("admin", $con_str) or die("Can't Connect to Database...");
			
	if (isset($_POST['register'])) 
	{
		if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['passwordAgain'])) 
		{
			$userName = $_POST['name'];
			$userEmail = $_POST['email'];
			$userPassword = $_POST['password'];
			$userPasswordAgain = $_POST['passwordAgain'];
			
			if($userPassword == $userPasswordAgain)
			{
					$query = "INSERT INTO admin.login VALUES('$userName','$userEmail','$userPassword')";
				
					if(!mysql_query($query)) 
					{
						die("Error : ".mysql_error());
					}
					else
					{
						echo "1 record added";
					}				
			}
			else 
			{
				echo "Password is not matched";	
			}				
		} 
		else 
		{
			echo "One or more fields are not added";
		}
		
	} 
	else 
	{
		echo "ABC";
	}
	
?>