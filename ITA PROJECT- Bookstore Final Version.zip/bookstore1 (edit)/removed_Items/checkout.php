﻿<?php 
	session_start();
	
	$con_str = mysql_connect("localhost", "root", "") or die("Can't Connect...");

	mysql_select_db("admin", $con_str) or die("Can't Connect to Database...");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Online BookStore - Checkout Page</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<link href="css/templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

</script>

<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "top_nav", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

<link rel="stylesheet" type="text/css" media="all" href="css/jquery.dualSlider.0.2.css" />

<script src="js/jquery-1.3.2.min.js" type="text/javascript"></script>
<script src="js/jquery.easing.1.3.js" type="text/javascript"></script>
<script src="js/jquery.timers-1.2.js" type="text/javascript"></script>

</head>

<body>

<div id="templatemo_wrapper">
	<div id="templatemo_header">
    	
    	<div id="site_title">
        	<h1><a href="#">Station Shop</a></h1>
        </div>
        
        <div id="header_right">
	        <?php
					
					if(isset($_SESSION['id'])){
					echo '<a href="account.php">';
					echo "Welcome :  ".$_SESSION['id']."  <b>My Account</b>";
					echo "</a>";
					echo " | "; 
					echo '<a href="shoppingcart.php">';
					echo "<b>My Cart</b>";
					echo "</a>";
					echo " | ";
					echo '<a href="checkout.php">';
					echo "<b>Checkout</b>";
					echo "</a>";
					echo " | ";
					echo '<a href="logout.php">';
					echo "<b>Log Out</b>";
					echo "</a>";
					}
					else {
					
					echo '<a href="account.php">';
					echo "<b>My Account</b>";
					echo "</a>";
					echo " | "; 
					echo '<a href="shoppingcart.php">';
					echo "<b>My Cart</b>";
					echo "</a>";
					echo " | ";
					echo '<a href="checkout.php">';
					echo "<b>Checkout</b>";
					echo "</a>";
					echo " | ";
					echo '<a href="login.php">';
					echo "<b>Log In</b>";
					echo "</a>";	
					}
					?>

		</div>
        
        <div class="cleaner"> </div>
    </div> <!-- END of templatemo_header -->
    
    <div id="templatemo_menu">
    	<div id="top_nav" class="ddsmoothmenu">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a>
                    <ul>
                        <li><a href="books.php">Books</a></li>
                        <li><a href="stationery.php">Stationeries</a></li>
                  	</ul>
                </li>
                <li><a href="about.php">About</a></li>
                <li><a href="checkout.php" class="selected">Checkout</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
            <br style="clear: left" />
        </div> <!-- end of ddsmoothmenu -->
        
        <div id="menu_second_bar">
        
        	<div id="top_shopping_cart">
            	Shopping Cart: <strong>3 Products</strong> ( <a href="shoppingcart.php">Show Cart</a> )
            </div>
        
        	<div id="templatemo_search">
				<form action="products.php" method="GET">
					<input type="text" value="Search" name="s" id="s" title="Search" onfocus="clearText(this)" onblur="clearText(this)" class="txt_field" />
					<input type="submit" value="Search" alt="s" id="searchbutton" title="Search" class="sub_btn"  />
				</form>
			</div>
            <div class="cleaner"> </div>
    	</div>
    </div> <!-- END of templatemo_menu -->
    
    <div id="templatemo_main">
   		<div id="sidebar" class="float_l">
        	<div class="sidebar_box"><span class="bottom"> </span>
            	
            	<h3>Categories</h3>   
                
                <div class="content"> 
                	<ul class="sidebar_list">
                    	
                    	<li class="first"><a href="products.php">New Arrivals</a></li><br/>
                        <li><a href="sinhala.php">Sinhala</a></li><br/>
                        <li><a href="English.php">English</a></li><br/>
                        <li><a href="#">Adult's</a></li><br/>
                        <li><a href="children.php">Children's</a></li><br/>
                        <li><a href="novel.php">Novels</a></li><br/>
                        
                    </ul>
                </div>
            
            </div>
            <div class="sidebar_box"><span class="bottom"> </span>
            	
            	<h3>Best Sellers </h3>   
                
                <div class="content"> 
                	
                	<div class="bs_box">
                    	<a href="#"><img src="images/templatemo_image_01.jpg" alt="Image 01" /></a>
                        <h4><a href="#">Rathna Publishers</a></h4>
                        
                        <div class="cleaner"> </div>
                    </div>
                    <div class="bs_box">
                    	<a href="#"><img src="images/templatemo_image_02.jpg" alt="Image 02" /></a>
                        <h4><a href="#">Gunasena Books</a></h4>
                        
                        <div class="cleaner"> </div>
                    </div>
                    <div class="bs_box">
                    	<a href="#"><img src="images/templatemo_image_03.jpg" alt="Image 03" /></a>
                        <h4><a href="#">Godage Books</a></h4>
                        
                        <div class="cleaner"> </div>
                    </div>
                    <div class="bs_box">
                    	<a href="#"><img src="images/templatemo_image_04.jpg" alt="Image 04" /></a>
                        <h4><a href="#">Samudra Bookshop</a></h4>
                        
                        <div class="cleaner"> </div>
                    </div>
                    <div class="bs_box">
                    	<a href="#"><img src="images/templatemo_image_05.jpg" alt="Image 05" /></a>
                        <h4><a href="#">Wasana Bookshop</a></h4>
                        
                        <div class="cleaner"> </div>
                    </div>
                    <div class="bs_box">
                    	<a href="#"><img src="images/templatemo_image_06.jpg" alt="Image 06" /></a>
                        <h4><a href="#">LakeHouse Bookshop</a></h4>
                        
                        <div class="cleaner"> </div>
                    </div>
               
                </div>
            </div>
        </div>
        
        <div id="content" class="float_r">
        
        	<h2>Checkout</h2>
            <h5><strong>BILLING DETAILS</strong></h5>
        
            <div class="content_half float_l checkout">
				Enter your full name as it is on the credit card:                				
                <input type="text"  style="width:300px;"  />
                Address:
                <input type="text"  style="width:300px;"  />
                City:
                <input type="text"  style="width:300px;"  />
                Country:
                <input type="text"  style="width:300px;"  />
            </div>
            
            <div class="content_half float_r checkout">
            	Email:
				<input type="text"  style="width:300px;"  />
                Phone:<br />
				<span style="font-size:10px">Please, specify your reachable phone number. YOU MAY BE GIVEN A CALL TO VERIFY AND COMPLETE THE ORDER.</span>
                <input type="text"  style="width:300px;"  />
            </div>
            
            <div class="cleaner h50"> </div>
            
            <h3>Shopping Cart</h3>
            <h4>TOTAL: <strong>$140</strong></h4>
			
			<p><input type="checkbox" />I have accepted the Terms of Use.</p>
            
            <table style="border:1px solid #CCCCCC;" width="100%">
                <tr>
                    <td height="80px"> <img src="images/paypal.gif" alt="paypal" /></td>
                    <td width="400px;" style="padding: 0px 20px;">Recommended if you have a PayPal account. Fastest delivery time.
                    </td>
                    <td><a href="#" class="more">PAYPAL</a></td>
                </tr>
                <tr>
                    <td  height="80px"><img src="images/2co.gif" alt="paypal" />
                    </td>
                    <td  width="400px;" style="padding: 0px 20px;">2Checkout, Inc. is an authorized retailer of goods and services provided by Template-Guide.com
2CheckOut accepts customer orders via online checks, Visa, MasterCard, Discover, American Express, Diners, JCB and debit cards with the Visa, Mastercard logo. Sed laoreet ornare ligula eu blandit. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.
                  </td>
                    <td><a href="#" class="more">2CHECKOUT</a></td>
                </tr>
            </table>
		</div>
        <div class="cleaner"> </div>
    </div> <!-- END of templatemo_main -->
    
    <div id="templatemo_footer">
    	<p>
			<a href="index.php">Home</a> | <a href="products.php">Products</a> | <a href="about.php">About</a> | <a href="checkout.php">Checkout</a> | <a href="contact.php">Contact</a>
		</p>

    	Copyright © 2048 <a href="index.php">Online BookStore</a>
    </div> <!-- END of templatemo_footer -->
    
</div> <!-- END of templatemo_wrapper -->

</body>
</html>