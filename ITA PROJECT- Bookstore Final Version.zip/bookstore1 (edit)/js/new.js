function hidden()
{
	document.getElementById("changeText").innerHTML = "Log out";
}
