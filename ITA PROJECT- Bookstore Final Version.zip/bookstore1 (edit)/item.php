<?php

class Item
{
	var $b_id;
	var $b_img;
	var $b_name;
	var $b_price;
	var $b_quantity;
	
}

?>