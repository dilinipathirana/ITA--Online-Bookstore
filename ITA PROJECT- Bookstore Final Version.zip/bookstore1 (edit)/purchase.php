<?php
	include "db_connect.php";
	

?>
	

	<!DOCTYPE html>
<html>
	<head>
		<title>Admin</title>
		
			
			
		
		<style>
			body{
				background-image:url("images/templatemo_body.jpg");
			}
			
			.content{
				
			border-radius:5px;
			background-color:#e6e6e6;
			padding: 50px 50px 50px;
			border: 2px;			
			width: 800px;
			margin-left: 200px;
			margin-top:100px;	
			}
			
		</style>
	</head>

		
<body >
	<a href="Admin_Home.php" style="color: white;"><center>Admin-Home</center></a>
<div class="content">
				<h2> <center>Admin Report</center> </h2>
				
	<?php
	$f=mysql_query("SELECT * FROM admin.history");

?>
<table  border="1" style="border-style: solid; border-width: thin; table-layout:initial">
	<caption>PURCHASE HISTORY</caption>
	<tr>
		<th>user_email</th>
		<th>user_name</th>
		<th>total-price</th>
		
			
		</tr>
	<?php
	
	if($f === FALSE) { 
    die(mysql_error()); 
}
	while($row=mysql_fetch_array($f)){
		
		echo "<tr>";
		echo "<td>".$row['user_email']."</td>";
		echo "<td>".$row['user_name']."</td>";
		echo "<td>".$row['total-price']."</td>";
		
		
		echo "</tr>";
	}
		
	echo "</table>";
	echo "<br/>";	
	
	
	?>
	
	
	
</div>
</body>
</html>