<!DOCTYPE html>
<html>
	<head>
		<title>Admin</title>
		
			
			
		
		<style>
		
		.pic{
			
			position: middle;
			margin-left: 375px;		
			
		}
		.one{
			background-color: white;
			margin-left: 375px;
			margin-right:375px;
			height: 150px;
			
		}
			
			body{
				background-image:url("images/templatemo_body.jpg");
			}
			</style>
			</head>
			
<body>
	
	<div class="pic">
	<img src="images/temp-puklus_rainbow_library.jpg" width="600px; " />
	</div>
	
	<div class="one">
		
		<h1 style="margin-left: 120px;">WELCOME ADMIN!!</h1>
		<a href="D_book.php" style="color: brown;padding: 6px; margin-left: 40px;">BOOKS</a>
		<a href="description.php"style="color: red;padding: 6px;">BOOK-DESCRIPTION</a>
		<a href="D_cat.php"style="color: orange;padding: 6px;">CATEGORY</a>
		<a href="D_login.php"style="color: yellow;padding: 6px;">USERS</a>
		<a href="D_contact.php"style="color: green;padding: 6px;">CONTACTS</a>
		<a href="purchase.php"style="color: blue;padding: 6px; margin-left: 200px; ">HISTORY</a>
		<a href="checkoutD.php"style="color: dodgerblue;padding: 6px;">CHECKOUT</a>
	</div>
	
	<a href="index.php" style="color: white;font-size: 17px"><center>Back to Home!!!</center></a>
	
	
	
	
	
	
	
	
	
</body>
</html>