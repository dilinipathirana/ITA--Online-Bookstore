<!DOCTYPE html>
	<html>
		<head>
			<style>
			body{
				background-image:url("images/templatemo_body.jpg");
				
			}
		.content{
			border-radius:5px;
			background-color:#e6e6e6;
			padding:50px 50px 50px;
			border: 2px;
			width:200px;
			margin-left:520px;
			margin-top:100px;}
			
			</style>
			</head>
			
		<body>
			<div class="content">
				<center> Successfully Paid </center>
				<a href="index.php"><center>Back To Home</center></a>
</div>
</body>
</html>
